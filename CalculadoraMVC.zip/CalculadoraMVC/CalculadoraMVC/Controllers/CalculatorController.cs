﻿using CalculadoraMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.JSInterop;
using Microsoft.AspNetCore.Hosting;
using CalculadoraMVC.Repositories;
using SQLitePCL;
using System.Text.Json;
using Newtonsoft.Json.Linq;

namespace CalculadoraMVC.Controllers
{
    public class CalculatorController : Controller
    {
        private ICalculatorRepository _repository;
        private IWebHostEnvironment _environment;

        public CalculatorController(ICalculatorRepository repository, IWebHostEnvironment environment)
        {
            _repository = repository;
            _environment = environment;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ListOperations()
        {
            return View(_repository.GetAll());
        }

        public IActionResult Create([FromBody] object operacion)
        {

            Calculator calc = new Calculator();
            JObject o = JObject.Parse(operacion.ToString());

            //calc.calculatorID = Guid.NewGuid();
            calc.operation = (string)o["operation"];
            calc.result = (string)o["result"];
            
            _repository.CreateCalculator(calc); 
            return RedirectToAction(nameof(Index));
        }
    }
}
