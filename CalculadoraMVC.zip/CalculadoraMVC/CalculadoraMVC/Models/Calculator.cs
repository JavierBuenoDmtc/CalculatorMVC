﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CalculadoraMVC.Models
{
    public class Calculator
    {
        [Key]
        public int calculatorID { get; set; }
        public string operation { get; set; }
        public string result { get; set; }
        public DateTime date { get; set; } 
    }
}
