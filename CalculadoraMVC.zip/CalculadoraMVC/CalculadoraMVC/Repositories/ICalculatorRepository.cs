﻿using CalculadoraMVC.Models;

namespace CalculadoraMVC.Repositories
{
    public interface ICalculatorRepository
    {
        IEnumerable<Calculator> GetAll();
        void CreateCalculator(Calculator calculator);
    }
}
