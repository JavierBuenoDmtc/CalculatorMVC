﻿using CalculadoraMVC.Data;
using CalculadoraMVC.Models;

namespace CalculadoraMVC.Repositories
{
    public class CalculatorRepository : ICalculatorRepository
    {
        private CalculatorContext _context;

        public CalculatorRepository(CalculatorContext context)
        {
            _context = context;
        }

        public IEnumerable<Calculator> GetAll()
        {
            return _context.Calculations.ToList();
        }

        public void CreateCalculator(Calculator calculator)
        {
            _context.Add(calculator);
            _context.SaveChanges();
        }


    }
}
