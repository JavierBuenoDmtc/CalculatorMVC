﻿
using CalculadoraMVC.Data;
using CalculadoraMVC.Models;
using CalculadoraMVC.Repositories;
using Microsoft.EntityFrameworkCore;

namespace CalculadoraMVC
{
    public class Startup
    {
        private IConfiguration _configuration;

        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<ICalculatorRepository, CalculatorRepository>();

            services.AddDbContext<CalculatorContext>(options =>
                 options.UseSqlite(_configuration.GetConnectionString("DefaultConnection")));


            services.AddMvc(options => options.EnableEndpointRouting = false);
        }

        public void Configure(IApplicationBuilder app)
        {

            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "CalculatorRoute",
                    template: "{controller}/{action}/{id?}",
                    defaults: new { controller = "Calculator", action = "Index" },
                    constraints: new { id = "[0-9]+" });
            });
        }
    }
}
